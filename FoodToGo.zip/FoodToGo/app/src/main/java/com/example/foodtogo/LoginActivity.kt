package com.example.foodtogo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    lateinit var mobile:EditText
    lateinit var password:EditText
    lateinit var forgot:TextView
    lateinit var signup: TextView
    lateinit var login:Button

    lateinit var sharedPreferences: SharedPreferences
    lateinit var mob :String
    lateinit var pass: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sharedPreferences = getSharedPreferences(getString(R.string.preference_file_name),Context.MODE_PRIVATE)



        mobile=findViewById(R.id.mobile)
        password=findViewById(R.id.password)
        forgot=findViewById(R.id.forgot)
        login=findViewById(R.id.login)
        signup=findViewById(R.id.signup)

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn",false)

        if(isLoggedIn)
        {
            var intent =Intent(this@LoginActivity,login_detail::class.java)
            startActivity(intent)
            finish()
        }
        signup.setOnClickListener {

            var intent = Intent(this@LoginActivity,register::class.java)
            startActivity(intent)
        }

        login.setOnClickListener {
            mob =mobile.text.toString()
            pass=password.text.toString()
            var intent = Intent(this@LoginActivity,login_detail::class.java)
            savePreferences(mob,pass)
            startActivity(intent)
        }

        forgot.setOnClickListener {
            var intent = Intent(this@LoginActivity,Forgot::class.java)
            startActivity(intent)
        }
    }
    fun savePreferences( mobile :String , password: String)
    {
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("mobile",mob).apply()
        sharedPreferences.edit().putString("password",pass).apply()
    }

    override fun onPause() {
        super.onPause()
        finish()
    }
}
