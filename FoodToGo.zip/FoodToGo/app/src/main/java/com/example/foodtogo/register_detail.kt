package com.example.foodtogo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView



class register_detail : AppCompatActivity() {

    lateinit var textname :TextView
    lateinit var textemail :TextView
    lateinit var textphone:TextView
    lateinit var textaddress:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_detail)

        textname=findViewById(R.id.textname)
        textphone=findViewById(R.id.textphone)
        textaddress=findViewById(R.id.textaddress)
        textemail=findViewById(R.id.textemail)

        if(intent!=null)
        {
            var name = intent.getStringExtra("name")
            var email= intent.getStringExtra("email")
            var mobile = intent.getStringExtra("mobile")
            var delivery = intent.getStringExtra("delivery")


            textname.text=name
            textaddress.text=delivery
            textemail.text=email
            textphone.text=mobile

        }
    }
}


