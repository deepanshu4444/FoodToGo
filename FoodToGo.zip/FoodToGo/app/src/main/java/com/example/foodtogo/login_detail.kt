package com.example.foodtogo

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class login_detail : AppCompatActivity() {

    lateinit var textmobile :TextView
    lateinit var textpassword: TextView
     var mobile : String="8949588158"
     var password : String="123456"
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_detail)

        sharedPreferences = getSharedPreferences(
            getString(R.string.preference_file_name),
            Context.MODE_PRIVATE
        )

        textmobile=findViewById(R.id.textmobile)
        textpassword=findViewById(R.id.textpassword)


           mobile = sharedPreferences.getString("mobile",mobile).toString()
        password= sharedPreferences.getString("password",password).toString()
            textmobile.text=mobile
            textpassword.text=password


    }
}
